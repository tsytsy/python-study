#!/usr/bin/env python
# _*_ coding:utf8 _*_

import os, sys



LOGIN_USERNAME = 'tsy'
LOGIN_PASSWD = '123'
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOST_CONF_DIR = os.path.join(BASE_DIR, 'conf', 'host_info.conf')

